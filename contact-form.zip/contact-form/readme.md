This form functionaliy was taken from the tutorial below:

https://h-educate.com/how-to-send-an-email-in-a-static-html-page-using-google-sheets-scripts/
